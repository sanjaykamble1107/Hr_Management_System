package com.hrmanagementsystem.entity;

public enum Gender {
M,F
}
