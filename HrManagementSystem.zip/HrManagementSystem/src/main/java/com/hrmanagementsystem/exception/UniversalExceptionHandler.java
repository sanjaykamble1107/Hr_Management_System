package com.hrmanagementsystem.exception;

public class UniversalExceptionHandler extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UniversalExceptionHandler() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UniversalExceptionHandler(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
