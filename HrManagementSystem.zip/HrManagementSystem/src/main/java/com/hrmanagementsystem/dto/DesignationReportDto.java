package com.hrmanagementsystem.dto;

public interface DesignationReportDto {

	public String getDesignation();
	public Double getAverageSalary();
	public Integer getMaxSalary();
	public Integer getMinSalary();
	}
