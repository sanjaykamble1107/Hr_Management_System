package com.hrmanagementsystem.dto;

public class ResponseDto {
	
	private String response;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ResponseDto [response=" + response + "]";
	}
	

}
