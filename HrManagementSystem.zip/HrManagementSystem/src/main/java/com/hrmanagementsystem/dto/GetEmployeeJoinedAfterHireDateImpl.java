package com.hrmanagementsystem.dto;

import java.time.LocalDate;

public class GetEmployeeJoinedAfterHireDateImpl implements GetEmployeeJoinedAfterHireDate {
	Integer employeeNumber;
	String firstName;
	String lastName;
	LocalDate hireDate;
	public Integer getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(Integer employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

}
